package com.zensar.service;

import com.zensar.dto.ProductDto;
import com.zensar.dto.ProductPageResponse;

/**
 * @author sbudime
 *
 */
public interface ProductService {

	public ProductDto createProduct(ProductDto prodcutDto);

	public ProductDto updateProduct(long productId,ProductDto prodcutDto);

	public ProductPageResponse getAllProduct(int pageNumber,int pageSize,String sortBy);

	public void deleteProductById(long productId);

}
