package com.zensar.externalservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.zensar.dto.CouponDto;
import com.zensar.dto.ProductDto;
import com.zensar.feignclient.CouponClient;
import com.zensar.service.ProductService;

@Service
public class CouponServiceCall {

	@Autowired
	private ProductService productService;

	/*
	 * @Autowired private RestTemplate restTemplate;
	 */

	@Autowired
	private CouponClient couponClient;

	public ProductDto callCouponService(ProductDto productDto) {
		// localhost:8082/api/coupons/MAX100

		/*
		 * ResponseEntity<CouponDto> responseCoupon = restTemplate
		 * .getForEntity("http://localhost:8082/api/coupons/" +
		 * productDto.getCouponCode(), CouponDto.class);
		 */

		/*
		 * ResponseEntity<CouponDto> responseCoupon = restTemplate
		 * .getForEntity("http://COUPON-SERVICE/api/coupons/"+productDto.getCouponCode()
		 * , CouponDto.class);
		 * 
		 * CouponDto coupon = responseCoupon.getBody();
		 */

		CouponDto coupon = couponClient.getCoupon(productDto.getCouponCode());
		//CouponDto coupon = getCoupon.getBody();

		productDto.setPrice(productDto.getPrice() - coupon.getDiscount());
		ProductDto createProduct = productService.createProduct(productDto);
		return createProduct;

	}

}
