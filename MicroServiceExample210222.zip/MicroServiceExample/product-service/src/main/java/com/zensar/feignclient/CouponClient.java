package com.zensar.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.zensar.dto.CouponDto;

//@FeignClient("http://localhost:8082/api/coupons")
@FeignClient("GATEWAY-SERVICE")
public interface CouponClient {

	// @GetMapping("/{couponCode}")
	@GetMapping("/api/coupons/{couponCode}")
	public CouponDto getCoupon(@PathVariable("couponCode") String couponCode);

}
