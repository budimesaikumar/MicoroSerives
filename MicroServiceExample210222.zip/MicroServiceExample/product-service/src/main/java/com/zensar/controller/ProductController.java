package com.zensar.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.dto.ProductDto;
import com.zensar.dto.ProductPageResponse;
import com.zensar.externalservice.CouponServiceCall;
import com.zensar.service.ProductService;

/**
 * @author sbudime
 *
 */

@RequestMapping("/api/products")
@RestController()
public class ProductController {

	@Autowired
	private ProductService productService;
	
	@Autowired
	private CouponServiceCall couponServiceCall;

	/**
	 * @param product
	 */
	@PostMapping("/")
	public ResponseEntity<ProductDto> createProduct(@RequestBody ProductDto productDto) {
		ProductDto createProduct=couponServiceCall.callCouponService(productDto);
		
		return new ResponseEntity<ProductDto>(createProduct, HttpStatus.CREATED);
	}

	@PutMapping("/{productId}")
	public ResponseEntity<Object> updateProducts(@PathVariable("productId") int productId,
			@RequestBody ProductDto productDto) {
		Map<String, Object> responseObj = new HashMap<>();
		responseObj.put("message", "Product" + productId + "  Updated..");
		productService.updateProduct(productId, productDto);
		responseObj.put("products", productDto);
		return new ResponseEntity<Object>(responseObj, HttpStatus.CREATED);
	}

	@GetMapping()
	public ProductPageResponse getAllPosts(
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "5", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "productId", required = false) String sortBy) {

		return productService.getAllProduct(pageNumber, pageSize, sortBy);
	}

	@DeleteMapping("/{productId}")
	public ResponseEntity<Object> deleteProductById(@PathVariable("productId") long productId) {
		Map<String, Object> responseObj = new HashMap<>();
		responseObj.put("message", "ProductId  " + productId + "  Deleted..");
		productService.deleteProductById(productId);
		return new ResponseEntity<Object>(responseObj, HttpStatus.CREATED);

	}

}
