package com.zensar.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.zensar.dto.ProductDto;
import com.zensar.dto.ProductPageResponse;
import com.zensar.model.Product;
import com.zensar.repository.ProductRepository;
import com.zensar.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Override
	public ProductDto createProduct(ProductDto prodcutDto) {
		Product product = modelMapper.map(prodcutDto, Product.class);
		return modelMapper.map(productRepository.save(product), ProductDto.class);
	}

	@Override
	public ProductDto updateProduct(long productId, ProductDto prodcutDto) {
		Product productById = productRepository.getById(productId);
		productById.setProductId(prodcutDto.getProductId());
		productById.setProductName(prodcutDto.getProductName());
		productById.setDiscription(prodcutDto.getDiscription());
		productById.setPrice(prodcutDto.getPrice());
		return modelMapper.map(productRepository.save(productById), ProductDto.class);

	}

	@Override
	public ProductPageResponse getAllProduct(int pageNumber, int pageSize, String sortBy) {
		Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by(sortBy).descending());

		Page<Product> posts = productRepository.findAll(pageable);

		List<Product> productList = posts.getContent();

		List<ProductDto> listOfProductDto = new ArrayList<>();

		for (Product product : productList) {

			ProductDto dto = modelMapper.map(product, ProductDto.class);
			listOfProductDto.add(dto);

		}

		ProductPageResponse prodcutPageResponse = new ProductPageResponse();

		prodcutPageResponse.setContent(listOfProductDto);
		prodcutPageResponse.setPageNumber(posts.getNumber());
		prodcutPageResponse.setPageSize(posts.getSize());
		prodcutPageResponse.setTotalElements(posts.getTotalElements());
		prodcutPageResponse.setTotalPages(posts.getTotalPages());
		prodcutPageResponse.setLast(posts.isLast());

		return prodcutPageResponse;
	}

	@Override
	public void deleteProductById(long productId) {
		productRepository.deleteById(productId);

	}

}
