package com.zensar.service;

import com.zensar.dto.CouponDto;
import com.zensar.dto.CouponPageResponse;

public interface CouponService {

	public CouponDto createCoupon(CouponDto couponDto);

	public CouponDto updateCoupon(long couponId, CouponDto couponDto);

	public CouponPageResponse getAllCoupon(int pageNumber, int pageSize, String sortBy);

	public void deleteCouponById(long couponId);

	public CouponDto getCoupon(String couponCode);

}
