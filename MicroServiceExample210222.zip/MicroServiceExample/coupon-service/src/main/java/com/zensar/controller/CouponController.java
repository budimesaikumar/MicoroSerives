package com.zensar.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.dto.CouponDto;
import com.zensar.dto.CouponPageResponse;
import com.zensar.service.CouponService;



@RestController
@RequestMapping("/api/coupons")
public class CouponController {
	
	@Autowired
	private CouponService couponService;
	
	@Value("${server.instance.name}")
	private String instanceName;

	/**
	 * @param product
	 */
	@PostMapping("/")
	public ResponseEntity<CouponDto> createProduct(@RequestBody CouponDto couponDto) {
		CouponDto createCoupon = couponService.createCoupon(couponDto);
		return new ResponseEntity<CouponDto>(createCoupon, HttpStatus.CREATED);
	}

	@PutMapping("/{coupnId}")
	public ResponseEntity<Object> updateProducts(@PathVariable("coupnId") int coupnId,
			@RequestBody CouponDto couponDto) {
		Map<String, Object> responseObj = new HashMap<>();
		responseObj.put("message", "Coupon" + coupnId + "  Updated..");
		couponService.updateCoupon(coupnId, couponDto);
		responseObj.put("products", couponDto);
		return new ResponseEntity<Object>(responseObj, HttpStatus.CREATED);
	}

	@GetMapping()
	public CouponPageResponse getAllPosts(
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "5", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "couponId", required = false) String sortBy) {

		return couponService.getAllCoupon(pageNumber, pageSize, sortBy);
	}

	@DeleteMapping("/{couponId}")
	public ResponseEntity<Object> deleteCouponById(@PathVariable("couponId") long couponId) {
		Map<String, Object> responseObj = new HashMap<>();
		responseObj.put("message", "CouponId  " + couponId + "  Deleted..");
		couponService.deleteCouponById(couponId);
		return new ResponseEntity<Object>(responseObj, HttpStatus.CREATED);

	}

	@GetMapping("/{couponCode}")
	public ResponseEntity<CouponDto> getCoupon(@PathVariable("couponCode") String couponCode) {
		System.out.println("Coupon service Running on "+ instanceName);
		//Map<String, Object> responseObj = new HashMap<>();
		//responseObj.put("message", "Getting   " + couponCode + " Details");
		CouponDto couponById = couponService.getCoupon(couponCode);
		//responseObj.put("coupon", couponById);
		return new ResponseEntity<CouponDto>(couponById, HttpStatus.CREATED);

	}
	
	

}
