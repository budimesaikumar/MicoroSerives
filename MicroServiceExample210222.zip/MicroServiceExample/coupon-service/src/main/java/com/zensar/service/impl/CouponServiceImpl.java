package com.zensar.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.zensar.dto.CouponDto;
import com.zensar.dto.CouponPageResponse;
import com.zensar.model.Coupon;
import com.zensar.repository.CouponRepository;
import com.zensar.service.CouponService;

@Service
public class CouponServiceImpl implements CouponService {

	@Autowired
	private CouponRepository couponRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Override
	public CouponDto createCoupon(CouponDto couponDto) {
		Coupon product = modelMapper.map(couponDto, Coupon.class);
		return modelMapper.map(couponRepository.save(product), CouponDto.class);
	}

	@Override
	public CouponDto updateCoupon(long couponId, CouponDto couponDto) {

		Coupon couponById = couponRepository.getById(couponId);
		couponById.setCouponId(couponDto.getCouponId());
		couponById.setCouponCode(couponDto.getCouponCode());
		couponById.setDiscount(couponDto.getDiscount());
		couponById.setExpDate(couponDto.getExpDate());
		return modelMapper.map(couponRepository.save(couponById), CouponDto.class);
	}

	@Override
	public CouponPageResponse getAllCoupon(int pageNumber, int pageSize, String sortBy) {
		Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by(sortBy).descending());

		Page<Coupon> coupons = couponRepository.findAll(pageable);

		List<Coupon> couponList = coupons.getContent();

		List<CouponDto> listOfcouponDto = new ArrayList<>();

		for (Coupon coupon : couponList) {

			CouponDto dto = modelMapper.map(coupon, CouponDto.class);
			listOfcouponDto.add(dto);

		}

		CouponPageResponse prodcutPageResponse = new CouponPageResponse();

		prodcutPageResponse.setContent(listOfcouponDto);
		prodcutPageResponse.setPageNumber(coupons.getNumber());
		prodcutPageResponse.setPageSize(coupons.getSize());
		prodcutPageResponse.setTotalElements(coupons.getTotalElements());
		prodcutPageResponse.setTotalPages(coupons.getTotalPages());
		prodcutPageResponse.setLast(coupons.isLast());

		return prodcutPageResponse;
	}

	@Override
	public void deleteCouponById(long couponId) {
		couponRepository.deleteById(couponId);
	}

	@Override
	public CouponDto getCoupon(String couponCode) {

		Coupon couponById = couponRepository.findByCouponCode(couponCode);
		return modelMapper.map(couponById, CouponDto.class);
	}

}
